"""Task A1 alternative: load the CSV into a pandas DataFrame for every question, or keep the data in SQLite."""
import csv
import json
import os
import sqlite3
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
import bigdata
import pandas as pd

R = []


def q_pandas(path):
    """The three questions, each starting with a fresh read_csv (the 'CSV only' design)."""
    out = []
    t0 = time.perf_counter()
    df = pd.read_csv(path, usecols=["station", "date", "hour", "pm25"])
    d = df[(df.station == "Adyar") & (df.date.between("2026-10-01", "2026-10-31"))]
    out.append(("Q1", d.pm25.mean(), time.perf_counter() - t0))
    t0 = time.perf_counter()
    df = pd.read_csv(path, usecols=["station", "date", "hour", "pm25"])
    top = df.groupby("station").pm25.mean().idxmax()
    out.append(("Q2", top, time.perf_counter() - t0))
    t0 = time.perf_counter()
    df = pd.read_csv(path, usecols=["station", "date", "hour", "pm25"])
    hrs = df.groupby("hour").pm25.mean().nlargest(3).index.tolist()
    out.append(("Q3", hrs, time.perf_counter() - t0))
    return out


QS = [("Q1", "SELECT AVG(pm25) FROM aq WHERE station = 'Adyar' AND day BETWEEN '2026-10-01' AND '2026-10-31'"),
      ("Q2", "SELECT station FROM aq GROUP BY station ORDER BY AVG(pm25) DESC LIMIT 1"),
      ("Q3", "SELECT hour FROM aq GROUP BY hour ORDER BY AVG(pm25) DESC LIMIT 3")]


def timed(con, sql, reps=3):
    best = float("inf")
    for _ in range(reps):
        t0 = time.perf_counter()
        res = con.execute(sql).fetchall()
        best = min(best, time.perf_counter() - t0)
    return best, res


if __name__ == "__main__":
    for st in (12, 120):
        path = bigdata.ensure_csv(st, 365)
        n = bigdata.row_count(path)
        print(f"\n=== {st} stations, {n:,} rows; CSV file {os.path.getsize(path) / 1e6:.1f} MB ===")
        db = os.path.join(tempfile.gettempdir(), f"a1_{st}.db")
        if os.path.exists(db):
            os.remove(db)
        con = sqlite3.connect(db)
        con.execute("CREATE TABLE aq (station TEXT, day TEXT, hour INTEGER, pm25 REAL)")
        t0 = time.perf_counter()
        with open(path, encoding="utf-8", newline="") as f:
            r = csv.reader(f)
            next(r)
            con.executemany("INSERT INTO aq VALUES (?, ?, ?, ?)", ((x[0], x[1], int(x[2]), float(x[3])) for x in r))
        con.commit()
        t_load = time.perf_counter() - t0
        print(f"one-off load into SQLite: {t_load:.2f} s; database file {os.path.getsize(db) / 1e6:.1f} MB")
        pd_res = [min((q_pandas(path) for _ in range(2)), key=lambda x: x[0][2] + x[1][2] + x[2][2])][0]
        res = {"stations": st, "rows": n, "csv_mb": os.path.getsize(path) / 1e6, "db_mb": os.path.getsize(db) / 1e6, "load": t_load}
        print(f"{'question':<10} {'pandas (read_csv each time)':>28} {'SQL, no index':>15} {'SQL, with index':>16}")
        sql_noidx = {q: timed(con, s) for q, s in QS}
        con.execute("CREATE INDEX idx_station_day ON aq (station, day)")
        con.commit()
        sql_idx = {q: timed(con, s) for q, s in QS}
        for (q, ans, t_pd) in pd_res:
            print(f"{q:<10} {t_pd * 1000:>25.1f} ms {sql_noidx[q][0] * 1000:>12.2f} ms {sql_idx[q][0] * 1000:>13.2f} ms")
            res[q] = {"pandas": t_pd, "sql": sql_noidx[q][0], "sql_idx": sql_idx[q][0]}
        assert abs(sql_idx["Q1"][1][0][0] - pd_res[0][1]) < 1e-6
        assert sql_idx["Q2"][1][0][0] == pd_res[1][1]
        assert [h[0] for h in sql_idx["Q3"][1]] == pd_res[2][1]
        print("answers identical:", pd_res[0][1], pd_res[1][1], pd_res[2][1])
        df = pd.read_csv(path, usecols=["station", "date", "hour", "pm25"])
        res["df_mb"] = df.memory_usage(deep=True).sum() / 1e6
        print(f"DataFrame in memory (4 columns): {res['df_mb']:.0f} MB for every question; SQLite reads pages from disk as needed")
        R.append(res)
        con.close()
        os.remove(db)
    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(R, f, indent=1)
