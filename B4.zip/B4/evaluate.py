"""Task B4.1 - sentiment scorer and summariser on 60 complaints, compared with my own reading."""
import csv
import json
import os
import time
import tracemalloc
from collections import Counter

import ai_tools as ai

HERE = os.path.dirname(os.path.abspath(__file__))
R = {}
rows = list(csv.DictReader(open(os.path.join(HERE, "complaints.csv"), encoding="utf-8")))
texts = [r["text"] for r in rows]
mine = [r["my_label"] for r in rows]
print(f"{len(rows)} complaints; my labels: {dict(Counter(mine))}")

print("\n=== Sentiment: agreement with my own reading ===")
versions = {"v0 assignment lexicon (one-word negation)": ai.score0,
            "v1 larger lexicon": ai.score1,
            "v2 larger lexicon + contractions + 'not very good'": ai.score2}
preds = {}
for name, fn in versions.items():
    preds[name] = [ai.to_label(fn(t)) for t in texts]
    agree = sum(p == m for p, m in zip(preds[name], mine))
    print(f"  {name:<52} agrees with {agree}/{len(rows)} = {agree / len(rows) * 100:.0f}%")
    R.setdefault("agree", {})[name] = agree

v0 = preds["v0 assignment lexicon (one-word negation)"]
conf = Counter(zip(mine, v0))
print("\nConfusion matrix of v0 (rows = my label, columns = scorer):")
labs = ["positive", "negative", "neutral"]
print(f"  {'':>9}" + "".join(f"{l:>10}" for l in labs))
for a in labs:
    print(f"  {a:>9}" + "".join(f"{conf[(a, b)]:>10}" for b in labs))
R["conf_v0"] = {f"{a}->{b}": conf[(a, b)] for a in labs for b in labs}
wrong0 = [(r["id"], t, m, p) for r, t, m, p in zip(rows, texts, mine, v0) if m != p]
print(f"\nExamples that v0 labels wrongly (first 8 of {len(wrong0)}):")
for i, t, m, p in wrong0[:8]:
    print(f"  #{i}: mine={m}, scorer={p} | {t}")
v2 = preds["v2 larger lexicon + contractions + 'not very good'"]
print("\nStill wrong with v2:")
for r, t, m, p in zip(rows, texts, mine, v2):
    if m != p:
        print(f"  #{r['id']}: mine={m}, scorer={p} | {t}")

print("\n=== Naive Bayes (trained from scratch) - leave-one-out on the 60 complaints ===")
ok = 0
for i in range(len(rows)):
    nb = ai.NaiveBayes().fit(texts[:i] + texts[i + 1:], mine[:i] + mine[i + 1:])
    ok += nb.predict(texts[i]) == mine[i]
print(f"  accuracy {ok}/{len(rows)} = {ok / len(rows) * 100:.0f}% (each complaint predicted by a model that never saw it)")
R["nb_loo"] = ok
nb = ai.NaiveBayes().fit(texts, mine)
print(f"  vocabulary {len(nb.vocab)} words; model size about {nb.size_bytes() / 1024:.0f} KiB")

print("\n=== Time and memory (60 complaints repeated to 50,000 = one month) ===")
big = (texts * 834)[:50_000]
for name, fn in (("v0 scorer", ai.score0), ("v2 scorer", ai.score2)):
    t0 = time.perf_counter()
    for t in big:
        fn(t)
    el = time.perf_counter() - t0
    print(f"  {name}: {el:.3f} s for 50,000 complaints = {el / 50_000 * 1e6:.1f} microseconds each")
    R[name] = el
t0 = time.perf_counter()
for t in big:
    nb.predict(t)
el = time.perf_counter() - t0
print(f"  Naive Bayes predict: {el:.3f} s for 50,000 = {el / 50_000 * 1e6:.1f} microseconds each")
R["nb_time"] = el
print(f"  lexicon memory: v0 sets {sum(len(s) for s in (ai.POSITIVE0, ai.NEGATIVE0, ai.NEGATORS0))} words; "
      f"v2 sets {len(ai.POSITIVE1) + len(ai.NEGATIVE1) + len(ai.NEGATORS2)} words")

print("\n=== Summariser: sentences with the most frequent important words vs first sentence ===")
freq = ai.word_freq(texts)
print("  most frequent important words:", freq.most_common(10))
long_rows = [r for r in rows if r["key_word"]]
hit_best = hit_first = 0
for r in long_rows:
    b, f = ai.summarise_best(r["text"], freq), ai.summarise_first(r["text"])
    hit_best += r["key_word"] in ai.words_of(b)
    hit_first += r["key_word"] in ai.words_of(f)
print(f"  {len(long_rows)} three-sentence complaints: key word kept by the frequency summariser {hit_best}/{len(long_rows)}, by first-sentence {hit_first}/{len(long_rows)}")
R["hit_best"], R["hit_first"], R["n_long"] = hit_best, hit_first, len(long_rows)
for r in long_rows[1:4] + long_rows[7:8]:
    print(f"  #{r['id']} key '{r['key_word']}'\n      frequency: {ai.summarise_best(r['text'], freq)}\n      first    : {ai.summarise_first(r['text'])}")
print("  where the frequency method missed the key word:")
for r in long_rows:
    if r["key_word"] not in ai.words_of(ai.summarise_best(r["text"], freq)):
        print(f"    #{r['id']} key '{r['key_word']}' -> chose: {ai.summarise_best(r['text'], freq)}")

all_sents = [s for t in texts for s in ai.sentences(t)]
top10 = [w for w, _ in freq.most_common(10)]
def cover(sel):
    got = {w for s in sel for w in ai.words_of(s)}
    return sum(w in got for w in top10)
best3 = sorted(all_sents, key=lambda s: -ai.sentence_score(s, freq))[:3]
first3 = all_sents[:3]
print(f"\n  corpus summary of 3 sentences covers {cover(best3)}/10 of the most frequent words (first 3 sentences: {cover(first3)}/10)")
for s in best3:
    print("    -", s)
R["cover_best"], R["cover_first"] = cover(best3), cover(first3)

print("\n=== Summariser time (per complaint, 3-sentence complaints, 5000 repeats) ===")
sample = [r["text"] for r in long_rows]
for name, fn in (("frequency summariser", lambda t: ai.summarise_best(t, freq)), ("first sentence", ai.summarise_first)):
    t0 = time.perf_counter()
    for _ in range(5000 // len(sample)):
        for t in sample:
            fn(t)
    el = (time.perf_counter() - t0) / (5000 // len(sample) * len(sample))
    print(f"  {name:<22} {el * 1e6:6.1f} microseconds per complaint")
    R["sum_time_" + name.split()[0]] = el
t0 = time.perf_counter(); ai.word_freq(big); el = time.perf_counter() - t0
print(f"  one-off word-frequency table for 50,000 complaints: {el:.3f} s")
tracemalloc.start(); f2 = ai.word_freq(big); mem = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
print(f"  memory of the frequency table: {mem / 1024:.0f} KiB for {len(f2)} distinct words (first-sentence method needs none)")
with open(os.path.join(HERE, "results.json"), "w") as f:
    json.dump(R, f, indent=1)
