"""Lexicon sentiment scorers, extractive summariser and a tiny Naive Bayes classifier (stdlib only)."""
import math
import re
import sys
from collections import Counter

# ----- version 0: exactly the lexicon of the assignment
POSITIVE0 = {"good", "clean", "fast", "helpful", "improved"}
NEGATIVE0 = {"bad", "dirty", "slow", "rude", "smoke", "broken"}
NEGATORS0 = {"not", "never", "no"}
# ----- version 1/2: larger lexicon (chosen AFTER reading the 60 complaints, so its accuracy is optimistic)
POSITIVE1 = POSITIVE0 | {"great", "excellent", "thank", "happy", "better", "polite", "useful", "accurate", "easy",
                         "appreciation", "quick", "comfortable", "less"}
NEGATIVE1 = NEGATIVE0 | {"terrible", "horrible", "worst", "unbearable", "dust", "fumes", "ill", "coughing", "crashing",
                         "missing", "overflowing", "dying", "unsafe", "late", "worse", "foam", "plastic", "burn", "burning",
                         "burned", "smell", "smells", "asthma", "unreliable", "jam"}
NEGATORS2 = NEGATORS0 | {"isn't", "aren't", "wasn't", "weren't", "don't", "doesn't", "didn't", "cannot", "can't", "nobody",
                         "nothing", "without"}
INTENSIFIERS = {"very", "so", "really", "at", "all", "too"}


def words_of(text):
    return re.findall(r"[a-z']+", text.lower())


def score0(text):
    words = text.lower().replace(".", " ").replace(",", " ").split()
    total = 0
    for i, w in enumerate(words):
        v = 1 if w in POSITIVE0 else -1 if w in NEGATIVE0 else 0
        if i > 0 and words[i - 1] in NEGATORS0:
            v = -v
        total += v
    return total


def score1(text):                      # larger lexicon, same one-word negation
    words = words_of(text)
    total = 0
    for i, w in enumerate(words):
        v = 1 if w in POSITIVE1 else -1 if w in NEGATIVE1 else 0
        if i > 0 and words[i - 1] in NEGATORS0:
            v = -v
        total += v
    return total


def score2(text):                      # larger lexicon + contractions + negator two words back, skipping intensifiers
    words = words_of(text)
    total = 0
    for i, w in enumerate(words):
        v = 1 if w in POSITIVE1 else -1 if w in NEGATIVE1 else 0
        if v:
            j = i - 1
            while j >= 0 and words[j] in INTENSIFIERS:
                j -= 1
            if j >= 0 and words[j] in NEGATORS2:
                v = -v
        total += v
    return total


def to_label(s):
    return "positive" if s > 0 else "negative" if s < 0 else "neutral"


# ----- extractive summariser
STOP = set("""a an and are as at be been but by can for from has have he her his i if in into is it its me my of on or our
she so that the their them there they this to was we were what when where which who will with you your hello hi sir dear
good morning evening name am about regarding greetings thank please kindly tell new small team request""".split()) - {"good"}


def sentences(text):
    return [s for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s]


def word_freq(texts):
    c = Counter()
    for t in texts:
        c.update(w for w in words_of(t) if w not in STOP and len(w) > 2)
    return c


def sentence_score(sentence, freq):
    ws = {w for w in words_of(sentence) if w not in STOP and freq.get(w, 0) >= 2}
    return sum(freq[w] for w in ws)


def summarise_best(text, freq, k=1):
    sents = sentences(text)
    ranked = sorted(range(len(sents)), key=lambda i: (-sentence_score(sents[i], freq), i))[:k]
    return " ".join(sents[i] for i in sorted(ranked))


def summarise_first(text, k=1):
    return " ".join(re.split(r"(?<=[.!?])\s+", text.strip(), maxsplit=k)[:k])


# ----- multinomial Naive Bayes
class NaiveBayes:
    def fit(self, texts, labels):
        self.classes = sorted(set(labels))
        self.prior = {c: math.log(labels.count(c) / len(labels)) for c in self.classes}
        self.counts = {c: Counter() for c in self.classes}
        for t, l in zip(texts, labels):
            self.counts[l].update(words_of(t))
        self.vocab = {w for c in self.classes for w in self.counts[c]}
        self.total = {c: sum(self.counts[c].values()) for c in self.classes}
        return self

    def predict(self, text):
        best, best_lp = None, -1e18
        V = len(self.vocab)
        for c in self.classes:
            lp = self.prior[c] + sum(math.log((self.counts[c][w] + 1) / (self.total[c] + V)) for w in words_of(text) if w in self.vocab)
            if lp > best_lp:
                best, best_lp = c, lp
        return best

    def size_bytes(self):
        return sum(sys.getsizeof(self.counts[c]) + sum(sys.getsizeof(k) + 28 for k in self.counts[c]) for c in self.classes)
