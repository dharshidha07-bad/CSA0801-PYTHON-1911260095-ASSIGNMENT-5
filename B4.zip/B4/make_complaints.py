"""Writes complaints.csv: 60 citizen complaints with MY OWN reading of each (positive / negative / neutral)
and, for the 20 three-sentence complaints, the key word that names the real problem."""
import csv
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SHORT = [
    ("The new air quality display at Adyar bus stop is very helpful.", "positive"),
    ("Thank you, the water tanker came on time and the staff were polite.", "positive"),
    ("Road sweeping has improved a lot in our street this month.", "positive"),
    ("The monitoring app is fast and easy to use.", "positive"),
    ("Excellent work by the corporation, the park is clean now.", "positive"),
    ("I am happy that the smoke from the garbage yard has stopped.", "positive"),
    ("Great service, my complaint was solved in two days.", "positive"),
    ("Air quality alerts reach me early, very useful.", "positive"),
    ("Staff at the helpline were helpful and listened patiently.", "positive"),
    ("Not bad, the bus service has improved since last year.", "positive"),
    ("The lake road is clean and the dust is much less.", "positive"),
    ("Heavy smoke from burning garbage near Manali every night.", "negative"),
    ("The air is bad and my children are coughing.", "negative"),
    ("Dust from the construction site is terrible, I cannot breathe.", "negative"),
    ("The helpline staff were rude and did not listen.", "negative"),
    ("The bus service is slow and always late.", "negative"),
    ("The staff were not helpful at all.", "negative"),
    ("Factory chimney releases black smoke at night.", "negative"),
    ("Garbage is not collected and the drain is dirty.", "negative"),
    ("No response to my complaint even after three reminders.", "negative"),
    ("The air quality display at Guindy is broken.", "negative"),
    ("Noise and pollution near the highway are unbearable.", "negative"),
    ("The app is slow and keeps crashing.", "negative"),
    ("The smell from the dump yard is horrible.", "negative"),
    ("Our area never gets clean water.", "negative"),
    ("The air isn't clean anymore, it smells of fumes.", "negative"),
    ("The monitoring station near us is not very good, readings are always missing.", "negative"),
    ("Worst air I have seen in years, the whole street is covered in dust.", "negative"),
    ("Oh great, another day of thick smog, just wonderful.", "negative"),
    ("Vehicles burn plastic on the roadside and nobody stops them.", "negative"),
    ("Buses are fast but the drivers are rude.", "negative"),
    ("The factory is not good for our health.", "negative"),
    ("Trucks raise so much dust that we keep the windows closed all day.", "negative"),
    ("Please share the timings of the mobile monitoring van.", "neutral"),
    ("Where can I see the air quality index of my area?", "neutral"),
    ("I want to know the contact number of the pollution control office.", "neutral"),
    ("How often is the PM2.5 reading updated?", "neutral"),
    ("Is there a station near Velachery?", "neutral"),
    ("Please send the monthly report of the Adyar station.", "neutral"),
    ("The monitoring van visited our street on Monday.", "neutral"),
]
LONG = [
    ("Hello sir, I live in Alandur near the metro station. The new air quality display there is very helpful. I can now plan my morning walk using the readings.", "positive", "display"),
    ("Good morning, I am writing from Velachery. Thick smoke from the factory near the lake has made my children ill for a week. Nobody from the corporation has visited.", "negative", "smoke"),
    ("I am a retired teacher living in Anna Nagar. The construction dust on our road is terrible every afternoon. Please send someone to check.", "negative", "dust"),
    ("To whom it may concern, I use the bus daily. The buses on route 21 are slow and always late. This makes me miss my office time.", "negative", "buses"),
    ("My name is Ravi and I live near Manali. Every night garbage is burned in the open yard. The smoke enters our houses and we cannot sleep.", "negative", "garbage"),
    ("Hello, this is regarding the helpline. The staff were rude when I called yesterday. They cut the call without listening.", "negative", "staff"),
    ("I live on Guindy industrial road. The air quality display at the signal is broken. It shows the same number since Monday.", "negative", "display"),
    ("Dear officer, we are residents of Egmore. The drain near the school is dirty and overflowing. Mosquitoes are increasing every day.", "negative", "drain"),
    ("Thank you for the quick action. The factory in our area has installed filters. The air feels much better now.", "positive", "filters"),
    ("Hi, I am new to Chennai. I want to understand the air quality index. Please tell me what the colours on the app mean.", "neutral", "colours"),
    ("I am writing about T. Nagar market. The traffic jam there produces a lot of smoke. Vendors and customers keep coughing.", "negative", "traffic"),
    ("This is a request from Kodungaiyur residents. The dump yard smell is horrible and spreads for two kilometres. Please shift the yard away from houses.", "negative", "smell"),
    ("Good evening, sir. My mother has asthma and lives with us in Perungudi. The dust from the road work has made her breathing worse.", "negative", "dust"),
    ("I am a shopkeeper in Royapuram. Trucks parked outside keep their engines running all day. The fumes make customers leave.", "negative", "trucks"),
    ("Hello team, a small appreciation. The mobile app notified me about high pollution before my jog. It was fast and accurate.", "positive", "app"),
    ("Regarding Sholinganallur, the lake is covered with foam. The water looks dirty and smells bad. Fish are dying near the bank.", "negative", "foam"),
    ("Sir, I am a student working on a project. I need the monthly PM2.5 data of Adyar and Guindy. Kindly tell me how to download it.", "neutral", "data"),
    ("I live near the highway. Burning of tyres happens near the bridge every weekend. The smoke is black and thick.", "negative", "tyres"),
    ("Greetings from Velachery. The streetlight on our lane is broken for two months. Women feel unsafe walking at night.", "negative", "streetlight"),
    ("Hi, regarding the pollution monitoring station in Manali. The readings are missing for many hours every day. The data is not reliable.", "negative", "readings"),
]
with open(os.path.join(HERE, "complaints.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f)
    w.writerow(["id", "text", "my_label", "key_word"])
    i = 0
    for text, lab in SHORT:
        i += 1
        w.writerow([i, text, lab, ""])
    for text, lab, key in LONG:
        i += 1
        w.writerow([i, text, lab, key])
print("wrote", i, "complaints")
