"""Task B4.2 - effect of an index on (station, day) on a 1,051,200-row table (120 stations, one year)."""
import csv
import json
import os
import sqlite3
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
import bigdata

QUERIES = {
    "Q1 mean PM2.5 of Adyar in October": ("SELECT AVG(pm25) FROM aq_flat WHERE station = ? AND day BETWEEN '2026-10-01' AND '2026-10-31'", ("Adyar",)),
    "Q2 station with the highest mean": ("SELECT station, AVG(pm25) m FROM aq_flat GROUP BY station ORDER BY m DESC LIMIT 1", ()),
    "Q3 three worst hours of the day": ("SELECT hour, AVG(pm25) m FROM aq_flat GROUP BY hour ORDER BY m DESC LIMIT 3", ()),
    "Q4 daily min/max/mean/count, one station": ("SELECT day, MIN(pm25), MAX(pm25), AVG(pm25), COUNT(pm25) FROM aq_flat WHERE station = ? GROUP BY day", ("Guindy",)),
}


def timeit(con, sql, params, reps):
    t = float("inf")
    for _ in range(reps):
        t0 = time.perf_counter()
        res = con.execute(sql, params).fetchall()
        t = min(t, time.perf_counter() - t0)
    return t, res


def measure(con, label, out):
    print(f"\n--- {label} ---")
    for name, (sql, p) in QUERIES.items():
        t, res = timeit(con, sql, p, 3)
        plan = " / ".join(r[3] for r in con.execute("EXPLAIN QUERY PLAN " + sql, p))
        out.setdefault(label, {})[name] = t
        print(f"  {name:<44} {t * 1000:9.2f} ms   plan: {plan}")


if __name__ == "__main__":
    path = bigdata.ensure_csv(120, 365)
    db = os.path.join(tempfile.gettempdir(), "a5_index_test.db")
    if os.path.exists(db):
        os.remove(db)
    con = sqlite3.connect(db)
    con.execute("CREATE TABLE aq_flat (station TEXT, day TEXT, hour INTEGER, pm25 REAL)")
    with open(path, encoding="utf-8", newline="") as f:
        r = csv.reader(f)
        next(r)
        con.executemany("INSERT INTO aq_flat VALUES (?, ?, ?, ?)", ((x[0], x[1], int(x[2]), float(x[3])) for x in r))
    con.commit()
    n = con.execute("SELECT COUNT(*) FROM aq_flat").fetchone()[0]
    size0 = os.path.getsize(db)
    print(f"{n:,} rows in table aq_flat (no index); database file {size0 / 1e6:.1f} MB")
    out = {"rows": n, "size0": size0}
    measure(con, "before: no index", out)
    slowest = max(out["before: no index"], key=out["before: no index"].get)
    print(f"\nSlowest query before indexing: {slowest}")
    out["slowest"] = slowest
    t0 = time.perf_counter()
    con.execute("CREATE INDEX idx_station_day ON aq_flat (station, day)")
    con.commit()
    out["index_build"] = time.perf_counter() - t0
    size1 = os.path.getsize(db)
    out["size1"] = size1
    print(f"\nCREATE INDEX idx_station_day ON aq_flat (station, day): {out['index_build']:.2f} s, file grows {size0 / 1e6:.1f} -> {size1 / 1e6:.1f} MB")
    measure(con, "after: index on (station, day)", out)
    con.execute("CREATE INDEX idx_hour_pm ON aq_flat (hour, pm25)")
    con.commit()
    measure(con, "after: plus covering index on (hour, pm25)", out)
    b, a = out["before: no index"], out["after: index on (station, day)"]
    print("\nSpeed-up from the (station, day) index:")
    for q in QUERIES:
        print(f"  {q:<44} {b[q] / a[q]:8.1f}x")
    with open(os.path.join(HERE, "index_results.json"), "w") as f:
        json.dump(out, f, indent=1)
    con.close()
    os.remove(db)
