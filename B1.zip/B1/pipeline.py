"""Task B1 - validate the cleaning pipeline, store in SQLite, query, visualise."""
import csv
import glob
import json
import os
import sqlite3
import statistics
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
import cleaning
import gen_data
import store

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = {}


def show(rows, header):
    print("  " + " | ".join(f"{h:>9}" for h in header))
    for r in rows:
        print("  " + " | ".join(f"{'' if v is None else v!s:>9}" for v in r))


# ------------------------------------------------------------------ B1.1 small file, before and after
print("=== B1.1 BEFORE cleaning (small_dirty.csv, 14 data lines, every problem of A1.1) ===")
print(open(os.path.join(HERE, "small_dirty.csv"), encoding="utf-8").read())
rows, rep = cleaning.clean_file(os.path.join(HERE, "small_dirty.csv"))
print("=== AFTER cleaning (station, date, hour, pm25, pm10, no2, temp_c, pm25_imputed) ===")
show(rows, ["station", "date", "hour", "pm25", "pm10", "no2", "temp_c", "imputed"])
print("\nCleaning report:", rep)
adyar = [r for r in rows if r[0] == "Adyar"]
manali = [r for r in rows if r[0] == "Manali"]
assert len(adyar) == 7 and len(manali) == 4, (len(adyar), len(manali))      # 2 bad rows + 1 duplicate removed
assert all(0 < r[6] < 40 for r in manali), "Fahrenheit not converted"
assert [r[3] for r in adyar] == [48.0, 48.0, 48.0, 52.0, 52.0, 52.0, 61.0], [r[3] for r in adyar]
print("Checks passed: names, dates, duplicate, bad rows, negatives, 9999, text, NA, Fahrenheit all handled.")
print("Manali temp: raw 80.6 F ->", manali[0][6], "C (expected", round((80.6 - 32) * 5 / 9, 1), ")")

print("\nmin-max of the cleaned Adyar pm25:", cleaning.min_max([r[3] for r in adyar]))
print("z-score of the cleaned Adyar pm25:", cleaning.z_score([r[3] for r in adyar]))

# ------------------------------------------------------------------ the real October files
print("\n=== Cleaning the 12 October station files ===")
all_rows, totals = [], {}
t0 = time.perf_counter()
for path in sorted(glob.glob(os.path.join(HERE, "data", "*.csv"))):
    r, rp = cleaning.clean_file(path)
    all_rows += r
    for k, v in rp.items():
        if isinstance(v, int):
            totals[k] = totals.get(k, 0) + v
    totals.setdefault("f_stations", []).extend(rp["fahrenheit_stations"])
t_clean = time.perf_counter() - t0
print(f"{len(all_rows):,} cleaned rows in {t_clean:.2f} s; problems found and fixed:")
for k in ("rows_read", "duplicates", "bad_date", "bad_hour", "missing", "impossible", "filled_pm25", "filled_other"):
    print(f"  {k:<12} {totals.get(k, 0):>7,}")
print("  stations converted from Fahrenheit:", totals["f_stations"])
R["cleaning_totals"] = {k: totals.get(k, 0) for k in ("rows_read", "duplicates", "missing", "impossible", "filled_pm25", "filled_other")}
R["f_stations"] = totals["f_stations"]
assert set(totals["f_stations"]) == gen_data.FAHRENHEIT_STATIONS

with open(os.path.join(HERE, "cleaned_october.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f)
    w.writerow(["station", "day", "hour", "pm25", "pm10", "no2", "temp_c", "pm25_imputed"])
    w.writerows(all_rows)

# ------------------------------------------------------------------ B1.3 SQLite
db_path = os.path.join(HERE, "air.db")
if os.path.exists(db_path):
    os.remove(db_path)
con = sqlite3.connect(db_path)
store.create_schema(con)
t0 = time.perf_counter()
store.load_rows(con, all_rows, gen_data.FAHRENHEIT_STATIONS)
t_load = time.perf_counter() - t0
n = con.execute("SELECT COUNT(*) FROM readings").fetchone()[0]
print(f"\nLoaded {n:,} readings into SQLite with executemany in {t_load:.3f} s (air.db)")

QUERIES = {
    "Q1 average PM2.5 of Adyar in October":
        ("SELECT ROUND(AVG(r.pm25), 2) FROM readings r JOIN stations s USING (station_id) "
         "WHERE s.name = ? AND r.day BETWEEN '2026-10-01' AND '2026-10-31'", ("Adyar",)),
    "Q2 station with the highest mean PM2.5":
        ("SELECT s.name, ROUND(AVG(r.pm25), 2) AS m FROM readings r JOIN stations s USING (station_id) "
         "GROUP BY s.name ORDER BY m DESC LIMIT 1", ()),
    "Q3 three worst hours of the day (mean PM2.5 over all stations)":
        ("SELECT r.hour, ROUND(AVG(r.pm25), 2) AS m FROM readings r GROUP BY r.hour ORDER BY m DESC LIMIT 3", ()),
}
print("\n=== B1.3 the three questions of A1.3, by SQL and by scanning the cleaned CSV ===")


def csv_answers(path):
    s_sum, s_cnt, h_sum, h_cnt, ad_sum, ad_cnt = {}, {}, {}, {}, 0.0, 0
    with open(path, encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f):
            if r["pm25"] == "":
                continue
            v = float(r["pm25"])
            s_sum[r["station"]] = s_sum.get(r["station"], 0) + v
            s_cnt[r["station"]] = s_cnt.get(r["station"], 0) + 1
            h = int(r["hour"])
            h_sum[h] = h_sum.get(h, 0) + v
            h_cnt[h] = h_cnt.get(h, 0) + 1
            if r["station"] == "Adyar":
                ad_sum += v
                ad_cnt += 1
    q1 = round(ad_sum / ad_cnt, 2)
    means = {k: s_sum[k] / s_cnt[k] for k in s_sum}
    top = max(means, key=means.get)
    hrs = sorted(((h_sum[h] / h_cnt[h], h) for h in h_sum), reverse=True)[:3]
    return q1, (top, round(means[top], 2)), [(h, round(m, 2)) for m, h in hrs]


sql_res = {}
for title, (sql, params) in QUERIES.items():
    t0 = time.perf_counter()
    for _ in range(20):
        res = con.execute(sql, params).fetchall()
    t_sql = (time.perf_counter() - t0) / 20
    sql_res[title] = res
    print(f"{title}\n    SQL: {res}   ({t_sql * 1000:.2f} ms per query)")
t0 = time.perf_counter()
for _ in range(5):
    c1, c2, c3 = csv_answers(os.path.join(HERE, "cleaned_october.csv"))
t_csv = (time.perf_counter() - t0) / 5
print(f"    CSV scan answers: {c1}, {c2}, {c3}   ({t_csv * 1000:.1f} ms for all three together)")
assert sql_res["Q1 average PM2.5 of Adyar in October"][0][0] == c1
assert sql_res["Q2 station with the highest mean PM2.5"][0] == c2
assert [tuple(x) for x in sql_res["Q3 three worst hours of the day (mean PM2.5 over all stations)"]] == c3
print("SQL and CSV answers agree: True")
R["answers"] = {"q1": c1, "q2": list(c2), "q3": [list(x) for x in c3]}

# ------------------------------------------------------------------ B1.4 charts
os.makedirs(os.path.join(HERE, "charts"), exist_ok=True)
daily = con.execute("SELECT s.name, r.day, AVG(r.pm25) FROM readings r JOIN stations s USING (station_id) "
                    "GROUP BY s.name, r.day ORDER BY s.name, r.day").fetchall()
fig, ax = plt.subplots(figsize=(7, 3.6))
trend = {}
for name in ("Adyar", "Guindy", "Manali"):
    pts = [(d[1][-2:], d[2]) for d in daily if d[0] == name]
    ax.plot([int(p[0]) for p in pts], [p[1] for p in pts], marker="o", ms=3, label=name)
    trend[name] = (pts[0][1], pts[-1][1], max(p[1] for p in pts))
ax.set_xlabel("Day of October 2026"); ax.set_ylabel("Daily mean PM2.5 (ug/m3)")
ax.set_title("Trend of PM2.5 over October (three stations)"); ax.grid(alpha=0.3); ax.legend()
fig.tight_layout(); fig.savefig(os.path.join(HERE, "charts", "1_trend_line.png"), dpi=150); plt.close(fig)
R["trend"] = {k: [round(x, 1) for x in v] for k, v in trend.items()}

means = con.execute("SELECT s.name, AVG(r.pm25) m FROM readings r JOIN stations s USING (station_id) "
                    "GROUP BY s.name ORDER BY m DESC").fetchall()
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.bar([m[0] for m in means], [m[1] for m in means], color="#2c5d8f")
ax.axhline(60, color="red", ls="--", lw=1, label="24-h standard 60 ug/m3 (India NAAQS)")
ax.set_ylabel("Mean PM2.5 (ug/m3)"); ax.set_xlabel("Station"); ax.set_title("Comparison of stations: October mean PM2.5")
plt.setp(ax.get_xticklabels(), rotation=45, ha="right"); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(HERE, "charts", "2_stations_bar.png"), dpi=150); plt.close(fig)
R["means"] = [[m[0], round(m[1], 1)] for m in means]

by_station = {}
for st, v in con.execute("SELECT s.name, r.pm25 FROM readings r JOIN stations s USING (station_id) WHERE r.pm25 IS NOT NULL"):
    by_station.setdefault(st, []).append(v)
order = [m[0] for m in means]
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.boxplot([by_station[s] for s in order], tick_labels=order, showfliers=True, flierprops={"markersize": 2})
ax.set_ylabel("Hourly PM2.5 (ug/m3)"); ax.set_xlabel("Station"); ax.set_title("Spread of hourly PM2.5 by station (box plot)")
plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
fig.tight_layout(); fig.savefig(os.path.join(HERE, "charts", "3_stations_box.png"), dpi=150); plt.close(fig)
R["spread"] = {s: [round(statistics.quantiles(by_station[s], n=4)[0], 1), round(statistics.quantiles(by_station[s], n=4)[2], 1)]
               for s in (order[0], order[-1])}

pts = con.execute("SELECT r.temp_c, r.pm25 FROM readings r JOIN stations s USING (station_id) "
                  "WHERE s.name = 'Guindy' AND r.temp_c IS NOT NULL AND r.pm25 IS NOT NULL").fetchall()
xs, ys = [p[0] for p in pts], [p[1] for p in pts]
r_corr = statistics.correlation(xs, ys)
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.scatter(xs, ys, s=8, alpha=0.5)
ax.set_xlabel("Temperature (C)"); ax.set_ylabel("PM2.5 (ug/m3)"); ax.set_title(f"Temperature and PM2.5, Guindy (r = {r_corr:.2f})")
ax.grid(alpha=0.3)
fig.tight_layout(); fig.savefig(os.path.join(HERE, "charts", "4_temp_scatter.png"), dpi=150); plt.close(fig)
R["corr"] = round(r_corr, 2)
R["scatter_n"] = len(pts)

allv = [v for vs in by_station.values() for v in vs]
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.hist(allv, bins=30, color="#6a1b9a", edgecolor="white")
ax.set_xlabel("PM2.5 (ug/m3)"); ax.set_ylabel("Number of hourly readings"); ax.set_title("Distribution of all valid PM2.5 readings")
fig.tight_layout(); fig.savefig(os.path.join(HERE, "charts", "5_pm25_histogram.png"), dpi=150); plt.close(fig)
R["hist"] = {"mean": round(statistics.fmean(allv), 1), "median": round(statistics.median(allv), 1), "max": round(max(allv), 1), "n": len(allv)}

hours = con.execute("SELECT hour, AVG(pm25) FROM readings GROUP BY hour ORDER BY hour").fetchall()
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.bar([h[0] for h in hours], [h[1] for h in hours], color="#e08a1e")
ax.set_xlabel("Hour of day"); ax.set_ylabel("Mean PM2.5 (ug/m3)"); ax.set_title("Hours with the worst air (all stations, October)")
ax.set_xticks(range(0, 24, 2))
fig.tight_layout(); fig.savefig(os.path.join(HERE, "charts", "6_hours_bar.png"), dpi=150); plt.close(fig)
R["hours"] = {"worst": c3, "best": [round(min(hours, key=lambda h: h[1])[0]), round(min(h[1] for h in hours), 1)]}
print("\n=== B1.4 charts written to B1/charts/ ===")
print("trend (first day, last day, peak daily mean):", R["trend"])
print("station means:", R["means"])
print(f"correlation temperature vs PM2.5 at Guindy: r = {R['corr']} (n = {R['scatter_n']})")
print("histogram:", R["hist"], "| hours:", R["hours"])
con.close()
with open(os.path.join(HERE, "results.json"), "w") as f:
    json.dump(R, f, indent=1)
