"""Writes 12 raw station CSV files for October 2026 (dirty) into B1/data/."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
import gen_data

os.makedirs(os.path.join(HERE, "data"), exist_ok=True)
for i, st in enumerate(gen_data.STATIONS):
    name = st.lower().replace(" ", "_").replace(".", "") + ".csv"
    with open(os.path.join(HERE, "data", name), "w", encoding="utf-8", newline="") as f:
        f.write(gen_data.dirty_csv(st, 31, seed=i * 10))
print("wrote", len(gen_data.STATIONS), "files in B1/data")
