"""Task B1 alternative concept: cleaning with pandas (vectorised) versus csv + loops.
Both start from the same CSV text and apply the same rules; time and peak memory are measured."""
import json
import os
import sys
import time
import tracemalloc

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
import cleaning
import gen_data

SIZES = [(1, 42), (12, 347), (12, 3472)]            # (stations, days) -> about 1,000 / 100,000 / 1,000,000 rows
out = []
print(f"{'rows':>10} {'loops time':>11} {'pandas time':>12} {'speed-up':>9} {'loops peak MB':>14} {'pandas peak MB':>15}")
for st, days in SIZES:
    text = gen_data.many_stations(st, days, dirty=True)
    n = text.count("\n") - 1
    reps = 3 if n < 200_000 else 1
    best_l = best_p = float("inf")
    for _ in range(reps):
        t0 = time.perf_counter(); rows, rep = cleaning.clean_text(text); best_l = min(best_l, time.perf_counter() - t0)
        t0 = time.perf_counter(); df = cleaning.clean_pandas(text); best_p = min(best_p, time.perf_counter() - t0)
    assert len(rows) == len(df), (len(rows), len(df))
    mean_l = sum(r[3] for r in rows if r[3] is not None) / sum(1 for r in rows if r[3] is not None)
    assert abs(mean_l - df["pm25"].mean()) < 0.01
    del rows, df
    tracemalloc.start(); r1, _ = cleaning.clean_text(text); peak_l = tracemalloc.get_traced_memory()[1]; tracemalloc.stop(); del r1
    tracemalloc.start(); d1 = cleaning.clean_pandas(text); peak_p = tracemalloc.get_traced_memory()[1]; tracemalloc.stop(); del d1
    out.append({"rows": n, "loops": best_l, "pandas": best_p, "mem_loops": peak_l, "mem_pandas": peak_p, "csv_mb": len(text) / 1e6})
    print(f"{n:>10,} {best_l:>10.3f}s {best_p:>11.3f}s {best_l / best_p:>8.1f}x {peak_l / 1e6:>14.1f} {peak_p / 1e6:>15.1f}   (CSV text {len(text) / 1e6:.1f} MB)", flush=True)
    del text
print("Both methods keep the same number of rows and the same mean PM2.5 (checked).")
with open(os.path.join(HERE, "alt_results.json"), "w") as f:
    json.dump(out, f, indent=1)
