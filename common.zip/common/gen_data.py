"""Synthetic air-quality data for the 12-station network (the real board files are not available).

make_truth()  -> clean hourly rows (what the sensors 'really' measured)
dirty_csv()   -> the same rows written as a messy station CSV text (problems of case study A1.1)
"""
import csv
import io
import math
import random
from datetime import date, timedelta

STATIONS = ["Adyar", "Alandur", "Anna Nagar", "Egmore", "Guindy", "Kodungaiyur", "Manali", "Perungudi",
            "Royapuram", "Sholinganallur", "T. Nagar", "Velachery"]
FAHRENHEIT_STATIONS = {"Manali", "Royapuram"}          # these two report temperature in degrees F
BASE_PM25 = {"Adyar": 38, "Alandur": 45, "Anna Nagar": 42, "Egmore": 55, "Guindy": 60, "Kodungaiyur": 85,
             "Manali": 95, "Perungudi": 50, "Royapuram": 75, "Sholinganallur": 40, "T. Nagar": 52, "Velachery": 44}
START = date(2026, 10, 1)
HEADER = ["station", "date", "hour", "pm25", "pm10", "no2", "temp"]


def make_truth(station, n_days, seed=0, start=START, base=None):
    """Clean hourly rows: dicts with station, date (ISO), hour, pm25, pm10, no2, temp_c."""
    rnd = random.Random(f"{station}-{seed}")
    base = BASE_PM25.get(station, 50) if base is None else base
    rows = []
    for d in range(n_days):
        day = start + timedelta(days=d)
        for h in range(24):
            temp = 27 + 5 * math.sin((h - 9) * math.pi / 12) + rnd.gauss(0, 0.6) - 0.02 * (d % 365)
            diurnal = 18 * math.exp(-((h - 8) / 2.5) ** 2) + 22 * math.exp(-((h - 21) / 3.0) ** 2)
            pm25 = base + 0.5 * (d % 31) + diurnal - 1.2 * (temp - 27) + rnd.gauss(0, 6)
            pm25 = max(3.0, pm25)
            pm10 = 1.6 * pm25 + rnd.gauss(0, 8)
            no2 = 20 + 0.3 * pm25 + rnd.gauss(0, 4)
            rows.append({"station": station, "date": day.isoformat(), "hour": h, "pm25": round(pm25, 1),
                         "pm10": round(max(5.0, pm10), 1), "no2": round(max(2.0, no2), 1), "temp_c": round(temp, 1)})
    return rows


def dirty_rows(rows, seed=1, dirty=True, fahrenheit=None):
    """Convert truth rows into raw CSV rows (lists of strings) with realistic problems."""
    rnd = random.Random(seed)
    fahrenheit = (rows[0]["station"] in FAHRENHEIT_STATIONS) if fahrenheit is None and rows else bool(fahrenheit)
    out = []
    for r in rows:
        temp = r["temp_c"] * 9 / 5 + 32 if fahrenheit else r["temp_c"]
        vals = {"pm25": r["pm25"], "pm10": r["pm10"], "no2": r["no2"], "temp": round(temp, 1)}
        station, day = r["station"], r["date"]
        if dirty:
            for k in ("pm25", "pm10", "no2", "temp"):
                u = rnd.random()
                if u < 0.04:
                    vals[k] = ""                         # blank
                elif u < 0.07:
                    vals[k] = "NA"                       # NA marker
                elif k != "temp" and u < 0.08:
                    vals[k] = rnd.choice([-5.0, -999.0, -1.0])      # negative sensor fault
                elif k != "temp" and u < 0.087:
                    vals[k] = rnd.choice([9999.0, 99999.0, 1500.0])  # impossibly large
            u = rnd.random()
            if u < 0.03:
                station = rnd.choice([station.lower(), station.upper(), "  " + station + " "])
            if rnd.random() < 0.02:
                y, m, d = day.split("-")
                day = f"{d}/{m}/{y}"                     # dd/mm/yyyy
        row = [station, day, r["hour"], vals["pm25"], vals["pm10"], vals["no2"], vals["temp"]]
        out.append(row)
        if dirty and rnd.random() < 0.005:
            out.append(list(row))                        # duplicated row
    return out


def to_csv_text(raw_rows, delimiter=","):
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=delimiter, lineterminator="\n")
    w.writerow(HEADER)
    w.writerows(raw_rows)
    return buf.getvalue()


def dirty_csv(station, n_days, seed=0, dirty=True):
    return to_csv_text(dirty_rows(make_truth(station, n_days, seed), seed=seed + 1, dirty=dirty))


def many_stations(n_stations, n_days, seed=0, dirty=False):
    """Rows for n stations (names beyond the 12 real ones are 'Station 013', ...), as raw CSV text."""
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(HEADER)
    for i in range(n_stations):
        name = STATIONS[i] if i < len(STATIONS) else f"Station {i + 1:03d}"
        base = BASE_PM25.get(name, 40 + (i * 7) % 50)
        truth = make_truth(name, n_days, seed, base=base)
        w.writerows(dirty_rows(truth, seed=seed + i + 1, dirty=dirty, fahrenheit=name in FAHRENHEIT_STATIONS))
    return buf.getvalue()


if __name__ == "__main__":
    print(dirty_csv("Adyar", 1)[:400])
