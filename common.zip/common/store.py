"""SQLite storage of the cleaned data (Task B1.3)."""
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS stations (
    station_id          INTEGER PRIMARY KEY,
    name                TEXT NOT NULL UNIQUE,
    reports_fahrenheit  INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS readings (
    station_id    INTEGER NOT NULL REFERENCES stations(station_id),
    day           TEXT    NOT NULL,                       -- ISO date YYYY-MM-DD
    hour          INTEGER NOT NULL CHECK (hour BETWEEN 0 AND 23),
    pm25          REAL,
    pm10          REAL,
    no2           REAL,
    temp_c        REAL,
    pm25_imputed  INTEGER NOT NULL DEFAULT 0,             -- 1 = pm25 was filled, not measured
    PRIMARY KEY (station_id, day, hour)
);
"""


def create_schema(con):
    con.executescript(SCHEMA)


def load_rows(con, rows, fahrenheit_stations=()):
    """rows: (station, date, hour, pm25, pm10, no2, temp_c, imputed). One executemany per table."""
    names = sorted({r[0] for r in rows})
    con.executemany("INSERT OR IGNORE INTO stations (name, reports_fahrenheit) VALUES (?, ?)",
                    [(n, 1 if n in fahrenheit_stations else 0) for n in names])
    ids = dict(con.execute("SELECT name, station_id FROM stations"))
    con.executemany(
        "INSERT OR REPLACE INTO readings (station_id, day, hour, pm25, pm10, no2, temp_c, pm25_imputed) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [(ids[r[0]], r[1], r[2], r[3], r[4], r[5], r[6], r[7]) for r in rows])
    con.commit()
    return ids
