"""Creates (and caches in the temp folder) the large CSV files used by B3, B4 and the Part A experiments."""
import os
import tempfile

import gen_data

CACHE = os.path.join(tempfile.gettempdir(), "a5_data")
HOURS_PER_YEAR = 365 * 24                      # 8,760 readings per station


def ensure_csv(stations, days=365, dirty=False, seed=0):
    """Return the path of a CSV with `stations` stations x `days` days of hourly readings (cached)."""
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, f"air_{stations}st_{days}d_{'dirty' if dirty else 'clean'}.csv")
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write(gen_data.many_stations(stations, days, seed=seed, dirty=dirty))
    return path


def row_count(path):
    with open(path, "rb") as f:
        return sum(1 for _ in f) - 1
