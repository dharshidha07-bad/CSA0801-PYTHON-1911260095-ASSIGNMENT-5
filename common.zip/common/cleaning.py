"""Cleaning, normalisation and formatting of station CSV files (Task B1)."""
import csv
import io
import statistics
from datetime import datetime

MISSING_TOKENS = {"", "na", "n/a", "nan", "null", "none", "-", "--"}
LIMITS = {"pm25": (0.0, 999.0), "pm10": (0.0, 999.0), "no2": (0.0, 999.0), "temp_c": (-10.0, 60.0)}
REQUIRED = ["station", "date", "hour", "pm25"]
OPTIONAL = ["pm10", "no2", "temp"]
FILL_LIMIT = 3                  # a pollutant may be carried forward for at most 3 consecutive missing readings
FAHRENHEIT_THRESHOLD = 50.0     # a station whose median 'temperature' exceeds this is reporting degrees F
DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d")


class CleaningError(Exception):
    """The file cannot be processed at all (empty, unreadable, required column missing)."""


# ---------------------------------------------------------------- reading the file safely
def decode_bytes(raw):
    """Return (text, note). Tries BOM-marked UTF-16/UTF-8, then UTF-8, then Windows-1252."""
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16"), "decoded as UTF-16 (byte-order mark found)"
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw.decode("utf-8-sig"), "UTF-8 byte-order mark removed"
    try:
        return raw.decode("utf-8"), None
    except UnicodeDecodeError:
        return raw.decode("cp1252", errors="replace"), "not valid UTF-8: decoded as Windows-1252"


def detect_delimiter(header_line):
    counts = {d: header_line.count(d) for d in (",", ";", "\t", "|")}
    best = max(counts, key=counts.get)
    return best if counts[best] > 0 else ","


# ---------------------------------------------------------------- single-value rules
def norm_station(s):
    return " ".join(s.strip().split()).title()


def norm_date(s):
    s = s.strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(s, fmt).date().isoformat()
        except ValueError:
            pass
    return None


def parse_number(s):
    """float, or None for a missing marker / text that is not a number."""
    s = (s or "").strip()
    if s.lower() in MISSING_TOKENS:
        return None
    try:
        v = float(s)
    except ValueError:
        return None
    return None if v != v else v          # NaN -> missing


def min_max(values):
    """Scale to 0..1; a constant series becomes all zeros; empty input gives []."""
    if not values:
        return []
    lo, hi = min(values), max(values)
    if hi == lo:
        return [0.0 for _ in values]
    return [round((v - lo) / (hi - lo), 3) for v in values]


def z_score(values):
    """(v - mean) / population standard deviation; constant series -> zeros."""
    if not values:
        return []
    mean = statistics.fmean(values)
    sd = statistics.pstdev(values)
    if sd == 0:
        return [0.0 for _ in values]
    return [round((v - mean) / sd, 3) for v in values]


# ---------------------------------------------------------------- the pipeline
def clean_text(text, delimiter=None):
    """Clean one station-CSV text. Returns (rows, report).

    rows   : list of (station, date, hour, pm25, pm10, no2, temp_c, pm25_imputed), sorted
    report : dict with the number of problems found and fixed
    """
    if not text.strip():
        raise CleaningError("file is empty")
    first_line = text.splitlines()[0]
    delimiter = delimiter or detect_delimiter(first_line)
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    fields = [f.strip().lower() for f in (reader.fieldnames or [])]
    reader.fieldnames = fields
    missing = [c for c in REQUIRED if c not in fields]
    if missing:
        raise CleaningError(f"required column(s) missing: {', '.join(missing)} (found: {ascii(', '.join(fields)[:40])})")
    absent_optional = [c for c in OPTIONAL if c not in fields]
    rep = {"delimiter": delimiter, "rows_read": 0, "bad_date": 0, "bad_hour": 0, "duplicates": 0, "missing": 0,
           "impossible": 0, "filled_pm25": 0, "filled_other": 0, "fahrenheit_stations": [],
           "absent_optional_columns": absent_optional}
    seen, recs = set(), []
    for raw in reader:
        rep["rows_read"] += 1
        station = norm_station(raw.get("station") or "")
        day = norm_date(raw.get("date") or "")
        try:
            hour = int(float((raw.get("hour") or "").strip()))
        except ValueError:
            hour = -1
        if day is None:
            rep["bad_date"] += 1
            continue
        if not 0 <= hour <= 23 or not station:
            rep["bad_hour"] += 1
            continue
        key = (station, day, hour)
        if key in seen:
            rep["duplicates"] += 1
            continue
        seen.add(key)
        recs.append([station, day, hour, parse_number(raw.get("pm25")), parse_number(raw.get("pm10")),
                     parse_number(raw.get("no2")), parse_number(raw.get("temp"))])
    # 1. Fahrenheit stations: median 'temperature' above the threshold -> convert to Celsius
    temps = {}
    for r in recs:
        if r[6] is not None:
            temps.setdefault(r[0], []).append(r[6])
    f_stations = {s for s, v in temps.items() if statistics.median(v) > FAHRENHEIT_THRESHOLD}
    rep["fahrenheit_stations"] = sorted(f_stations)
    for r in recs:
        if r[0] in f_stations and r[6] is not None:
            r[6] = (r[6] - 32) * 5 / 9
    # 2. impossible values become missing
    for r in recs:
        for idx, col in ((3, "pm25"), (4, "pm10"), (5, "no2"), (6, "temp_c")):
            v = r[idx]
            if v is None:
                rep["missing"] += 1
            elif not LIMITS[col][0] <= v <= LIMITS[col][1]:
                r[idx] = None
                rep["impossible"] += 1
    # 3. order, then fill
    recs.sort(key=lambda r: (r[0], r[1], r[2]))
    imputed = [0] * len(recs)
    last = {}                                   # (station, column index) -> [last valid value, run of missing]
    for i, r in enumerate(recs):
        for idx in (3, 4, 5):
            st = last.setdefault((r[0], idx), [None, 0])
            if r[idx] is not None:
                st[0], st[1] = r[idx], 0
            else:
                st[1] += 1
                if st[0] is not None and st[1] <= FILL_LIMIT:
                    r[idx] = st[0]
                    if idx == 3:
                        imputed[i] = 1
                        rep["filled_pm25"] += 1
                    else:
                        rep["filled_other"] += 1
    day_temps = {}
    for r in recs:
        if r[6] is not None:
            day_temps.setdefault((r[0], r[1]), []).append(r[6])
    day_median = {k: statistics.median(v) for k, v in day_temps.items()}
    for r in recs:
        if r[6] is None and (r[0], r[1]) in day_median:
            r[6] = day_median[(r[0], r[1])]
            rep["filled_other"] += 1
    rows = [(r[0], r[1], r[2], *(None if v is None else round(v, 1) for v in r[3:7]), imputed[i])
            for i, r in enumerate(recs)]
    return rows, rep


def clean_file(path):
    with open(path, "rb") as f:
        raw = f.read()
    text, note = decode_bytes(raw)
    rows, rep = clean_text(text)
    rep["encoding_note"] = note
    return rows, rep


def clean_pandas(text):
    """The same rules with pandas (vectorised) - used by the 'alternative concept' comparison."""
    import numpy as np
    import pandas as pd
    df = pd.read_csv(io.StringIO(text), dtype=str, keep_default_na=False)
    df.columns = [c.strip().lower() for c in df.columns]
    df["station"] = df["station"].str.strip().str.split().str.join(" ").str.title()
    d1 = pd.to_datetime(df["date"].str.strip(), format="%Y-%m-%d", errors="coerce")
    d2 = pd.to_datetime(df["date"].str.strip(), format="%d/%m/%Y", errors="coerce")
    df["date"] = d1.fillna(d2)
    df["hour"] = pd.to_numeric(df["hour"], errors="coerce")
    df = df[df["date"].notna() & df["hour"].between(0, 23) & (df["station"] != "")].copy()
    df["hour"] = df["hour"].astype(int)
    df = df.drop_duplicates(subset=["station", "date", "hour"], keep="first")
    for c in ("pm25", "pm10", "no2", "temp"):
        df[c] = pd.to_numeric(df[c].str.strip().replace({"": np.nan, "NA": np.nan, "na": np.nan}), errors="coerce")
    med = df.groupby("station")["temp"].transform("median")
    is_f = med > FAHRENHEIT_THRESHOLD
    df.loc[is_f, "temp"] = (df.loc[is_f, "temp"] - 32) * 5 / 9
    for c, key in (("pm25", "pm25"), ("pm10", "pm10"), ("no2", "no2"), ("temp", "temp_c")):
        lo, hi = LIMITS[key]
        df.loc[~df[c].between(lo, hi), c] = np.nan
    df = df.sort_values(["station", "date", "hour"]).reset_index(drop=True)
    was_missing = df["pm25"].isna()
    for c in ("pm25", "pm10", "no2"):
        df[c] = df.groupby("station")[c].ffill(limit=FILL_LIMIT)
    df["pm25_imputed"] = (was_missing & df["pm25"].notna()).astype(int)
    df["temp"] = df["temp"].fillna(df.groupby(["station", "date"])["temp"].transform("median"))
    df = df.rename(columns={"temp": "temp_c"})
    for c in ("pm25", "pm10", "no2", "temp_c"):
        df[c] = df[c].round(1)
    df["date"] = df["date"].dt.strftime("%Y-%m-%d")
    return df
