"""Task B2 - adversarial inputs: bad files, SQL quote characters, sentences that fool the sentiment scorer."""
import json
import os
import sqlite3
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
sys.path.insert(0, os.path.join(HERE, "..", "B4"))
import cleaning
import store
import ai_tools as ai

R = {}
tmp = tempfile.mkdtemp()


def write(name, data):
    path = os.path.join(tmp, name)
    with open(path, "wb") as f:
        f.write(data)
    return path


GOOD = "station,date,hour,pm25,pm10,no2,temp\nAdyar,2026-10-01,0,48,77,30,27.5\nAdyar,2026-10-01,1,50,80,31,27.0\n"
print("=== B2.1 awkward files given to the cleaning program (cleaning.clean_file) ===")
cases = [
    ("missing column (no pm25)", GOOD.replace(",pm25", "").encode()),
    ("wrong delimiter (semicolons)", GOOD.replace(",", ";").encode()),
    ("Windows-1252 text (Perungudi with e-acute)", GOOD.replace("Adyar", "P\u00e9rungudi").encode("cp1252")),
    ("UTF-16 with byte-order mark", GOOD.encode("utf-16")),
    ("UTF-8 with byte-order mark", b"\xef\xbb\xbf" + GOOD.encode()),
    ("completely empty file", b""),
    ("only blank lines", b"\n\n  \n"),
    ("header only, no data rows", GOOD.split("\n")[0].encode() + b"\n"),
    ("header in capitals with spaces", GOOD.replace("station,date,hour,pm25", " STATION , Date ,Hour, PM25 ").encode()),
    ("binary garbage", bytes(range(128, 256)) * 3),
]
table = []
for label, data in cases:
    try:
        rows, rep = cleaning.clean_file(write("t.csv", data))
        note = f"OK: {len(rows)} rows, delimiter {rep['delimiter']!r}" + (f", note: {rep['encoding_note']}" if rep["encoding_note"] else "") \
            + (f", optional columns absent: {rep['absent_optional_columns']}" if rep["absent_optional_columns"] else "")
        if rows:
            note += f", first station: {rows[0][0]!r}"
    except cleaning.CleaningError as e:
        note = f"rejected with a clear message: CleaningError: {e}"
    except Exception as e:
        note = f"UNEXPECTED {type(e).__name__}: {e}"
    table.append((label, note))
    print(f"  {label:<44} -> {note}")
R["files"] = table

print("\n=== B2.2 a station name containing a quote character ===")
con = sqlite3.connect(":memory:")
store.create_schema(con)
store.load_rows(con, [("Adyar", "2026-10-01", 0, 48.0, 77.0, 30.0, 27.5, 0), ("Adyar", "2026-10-01", 1, 52.0, 80.0, 31.0, 27.0, 0),
                      ("Besant Nagar's", "2026-10-01", 0, 70.0, 100.0, 40.0, 28.0, 0), ("Guindy", "2026-10-01", 0, 95.0, 150.0, 50.0, 29.0, 0)])
JOIN = "FROM readings r JOIN stations s USING (station_id) WHERE s.name = "


def concatenated(name):
    sql = "SELECT AVG(r.pm25) " + JOIN + "'" + name + "'"
    return sql, con.execute(sql).fetchone()[0]


def placeholder(name):
    return con.execute("SELECT AVG(r.pm25) " + JOIN + "?", (name,)).fetchone()[0]


for name in ("Adyar", "Besant Nagar's", "Adyar' OR '1'='1", "x'; DROP TABLE readings; --"):
    print(f"\n  input: {name!r}")
    try:
        sql, res = concatenated(name)
        print(f"    with +  : SQL text = ...WHERE s.name = '{name}'   ->  result {res}")
    except Exception as e:
        print(f"    with +  : {type(e).__name__}: {e}")
    print(f"    with ?  : result {placeholder(name)}")
print("\n  rows in readings after all attempts:", con.execute("SELECT COUNT(*) FROM readings").fetchone()[0], "(the DROP never ran)")
all_avg = con.execute("SELECT AVG(pm25) FROM readings").fetchone()[0]
print(f"  mean of ALL rows = {all_avg:.2f}: this is what the OR '1'='1' input leaked through string concatenation")
R["all_avg"] = all_avg
con.close()

print("\n=== B2.3 sentiment scorer on sentences built to fool it (v0 = assignment lexicon, v2 = larger lexicon + better negation) ===")
tests = [
    ("sarcasm", "Oh great, another day of thick smog, just wonderful.", "negative"),
    ("sarcasm 2", "Fantastic, the air display is broken again.", "negative"),
    ("double negative (hedged)", "I cannot say the service is not good.", "positive"),
    ("double negative 2", "Nobody can say the water is not dirty.", "negative"),
    ("mixed opinion", "The buses are fast but the drivers are rude.", "negative"),
    ("mixed opinion 2", "Air is clean in the morning but terrible in the evening.", "negative"),
    ("negator two words back", "The staff were not very helpful.", "negative"),
    ("contraction", "The air isn't clean.", "negative"),
    ("no lexicon word", "My children cannot breathe near the dump yard.", "negative"),
    ("misspelling", "The service was gud and fast.", "positive"),
    ("word in another sense", "Please do not smoke near the station, thank you for the clean platform.", "positive"),
    ("question", "Is the air clean today?", "neutral"),
]
rows = []
for kind, text, truth in tests:
    s0, s2 = ai.score0(text), ai.score2(text)
    l0, l2 = ai.to_label(s0), ai.to_label(s2)
    rows.append((kind, text, truth, l0, l2))
    print(f"  {kind:<22} truth={truth:<8} v0={l0:<8} v2={l2:<8} {'FAIL' if l0 != truth else 'ok  '}/{'FAIL' if l2 != truth else 'ok  '} | {text}")
R["sentiment"] = rows
print(f"  v0 correct on {sum(r[3] == r[2] for r in rows)}/{len(rows)}, v2 correct on {sum(r[4] == r[2] for r in rows)}/{len(rows)}")

print("\n=== Alternative concept: executemany versus execute() in a loop, and a commit after every row ===")
print(f"  {'n rows':>9} {'executemany':>12} {'execute loop':>13} {'ratio':>7}")
timing = []
for n in (1_000, 10_000, 100_000, 500_000):
    data = [("Adyar", f"2026-{(i % 12) + 1:02d}-{(i % 28) + 1:02d}", float(i % 200)) for i in range(n)]
    best_m = best_l = float("inf")
    for _ in range(3 if n <= 100_000 else 1):
        c = sqlite3.connect(":memory:"); c.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
        t0 = time.perf_counter(); c.executemany("INSERT INTO aq VALUES (?, ?, ?)", data); c.commit(); best_m = min(best_m, time.perf_counter() - t0); c.close()
        c = sqlite3.connect(":memory:"); c.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
        t0 = time.perf_counter()
        for row in data:
            c.execute("INSERT INTO aq VALUES (?, ?, ?)", row)
        c.commit(); best_l = min(best_l, time.perf_counter() - t0); c.close()
    timing.append({"n": n, "many": best_m, "loop": best_l})
    print(f"  {n:>9,} {best_m:>11.4f}s {best_l:>12.4f}s {best_l / best_m:>6.2f}x", flush=True)
R["insert_timing"] = timing
n = 2000
data = [("Adyar", "2026-10-01", float(i)) for i in range(n)]
path = os.path.join(tmp, "commit_test.db")
c = sqlite3.connect(path); c.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)"); c.commit()
t0 = time.perf_counter()
for row in data:
    c.execute("INSERT INTO aq VALUES (?, ?, ?)", row)
    c.commit()
t_each = time.perf_counter() - t0
c.close(); os.remove(path)
c = sqlite3.connect(path); c.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)"); c.commit()
t0 = time.perf_counter(); c.executemany("INSERT INTO aq VALUES (?, ?, ?)", data); c.commit(); t_one = time.perf_counter() - t0
c.close()
print(f"  file database, {n:,} rows: commit after every row {t_each:.3f} s versus one executemany + one commit {t_one:.4f} s ({t_each / t_one:,.0f}x)")
R["commit"] = {"each": t_each, "one": t_one, "n": n}
with open(os.path.join(HERE, "results.json"), "w") as f:
    json.dump(R, f, indent=1, default=str)
