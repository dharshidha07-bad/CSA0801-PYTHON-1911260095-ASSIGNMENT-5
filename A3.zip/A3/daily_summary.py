"""Task A3: the daily summary table per station (min, max, mean, number of valid readings) by SQL GROUP BY
and, as the alternative concept, by Python loops after reading all rows."""
import csv
import json
import os
import sqlite3
import statistics
import sys
import time
import tracemalloc

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
import bigdata

SQL = ("SELECT s.name AS station, r.day, MIN(r.pm25) AS min_pm25, MAX(r.pm25) AS max_pm25, "
       "ROUND(AVG(r.pm25), 2) AS mean_pm25, COUNT(r.pm25) AS valid_readings "
       "FROM readings r JOIN stations s USING (station_id) GROUP BY s.name, r.day ORDER BY s.name, r.day")


def loops_summary(path):
    groups = {}
    with open(path, encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        next(reader)
        for station, day, hour, pm25, *rest in reader:
            if pm25 != "":
                groups.setdefault((station, day), []).append(float(pm25))
    return {k: (min(v), max(v), round(statistics.fmean(v), 2), len(v)) for k, v in groups.items()}


def sql_summary(con):
    return {(s, d): (a, b, m, n) for s, d, a, b, m, n in con.execute(
        "SELECT station, day, MIN(pm25), MAX(pm25), ROUND(AVG(pm25), 2), COUNT(pm25) FROM aq GROUP BY station, day")}


def best(fn, reps):
    t = float("inf")
    for _ in range(reps):
        t0 = time.perf_counter(); fn(); t = min(t, time.perf_counter() - t0)
    return t


if __name__ == "__main__":
    print("=== daily summary table from the October database built in B1 (SQL GROUP BY) ===")
    con = sqlite3.connect(os.path.join(HERE, "..", "B1", "air.db"))
    con.execute("DROP TABLE IF EXISTS daily_summary_demo")
    rows = con.execute(SQL).fetchall()
    print(f"{'station':<12}{'day':<12}{'min':>7}{'max':>7}{'mean':>8}{'valid':>7}")
    for r in rows[:5] + rows[-2:]:
        print(f"{r[0]:<12}{r[1]:<12}{r[2]:>7}{r[3]:>7}{r[4]:>8}{r[5]:>7}")
    print(f"... {len(rows)} rows (12 stations x 31 days)")
    con.close()

    print("\n=== SQL GROUP BY versus Python loops (same four statistics, results compared) ===")
    print(f"{'rows':>10} {'loops time':>11} {'loops peak MB':>14} {'SQL time':>9} {'SQL peak MB':>12}")
    out = []
    for st in (12, 120):
        path = bigdata.ensure_csv(st, 365)
        n = bigdata.row_count(path)
        c = sqlite3.connect(":memory:")
        c.execute("CREATE TABLE aq (station TEXT, day TEXT, hour INTEGER, pm25 REAL)")
        with open(path, encoding="utf-8", newline="") as f:
            r = csv.reader(f); next(r)
            c.executemany("INSERT INTO aq VALUES (?, ?, ?, ?)", ((x[0], x[1], int(x[2]), float(x[3])) for x in r))
        reps = 3 if n < 500_000 else 1
        t_l, t_s = best(lambda: loops_summary(path), reps), best(lambda: sql_summary(c), reps)
        tracemalloc.start(); a = loops_summary(path); m_l = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
        tracemalloc.start(); b = sql_summary(c); m_s = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
        assert a.keys() == b.keys() and all(abs(a[k][2] - b[k][2]) < 0.011 and a[k][0] == b[k][0] and a[k][1] == b[k][1] and a[k][3] == b[k][3] for k in a)
        out.append({"rows": n, "loops": t_l, "sql": t_s, "mem_loops": m_l, "mem_sql": m_s})
        print(f"{n:>10,} {t_l:>10.3f}s {m_l / 1e6:>14.1f} {t_s:>8.3f}s {m_s / 1e6:>12.1f}")
        c.close()
    print("Both approaches give the same summary table (checked). SQL time excludes the one-off load; memory counts Python objects only.")
    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(out, f, indent=1)
