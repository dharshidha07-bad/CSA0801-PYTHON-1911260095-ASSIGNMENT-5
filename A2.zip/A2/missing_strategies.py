"""Task A2 alternative: drop missing readings, or fill them (previous value / median)?  Truth is known, so the error is measurable."""
import json
import os
import random
import statistics
import sys
import time
import tracemalloc
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
import gen_data

R = {}


def make_masked(seed=3):
    """truth[station][(day, hour)] = pm25; masked = same keys, None where the sensor sent nothing."""
    rnd = random.Random(seed)
    truth, masked = {}, {}
    for st in gen_data.STATIONS:
        rows = gen_data.make_truth(st, 31, seed=seed)
        truth[st] = [(r["date"], r["hour"], r["pm25"]) for r in rows]
        vals = [r["pm25"] for r in rows]
        keep = [True] * len(vals)
        for i in range(len(vals)):
            if rnd.random() < 0.05:
                keep[i] = False
        for i in range(0, len(vals), 24):                      # a burst outage of 5-8 hours on some days
            if rnd.random() < 0.25:
                s = i + rnd.randrange(0, 16)
                for j in range(s, min(s + rnd.randint(5, 8), len(vals))):
                    keep[j] = False
        masked[st] = [None if not k else v for k, v in zip(keep, vals)]
    return truth, masked


def strategy_drop(vals):
    return vals


def strategy_ffill(vals, limit=3):
    out, last, run = [], None, 0
    for v in vals:
        if v is None:
            run += 1
            out.append(last if last is not None and run <= limit else None)
        else:
            last, run = v, 0
            out.append(v)
    return out


def strategy_median(vals):
    known = sorted(v for v in vals if v is not None)                # O(n log n) sort
    n = len(known)
    med = known[n // 2] if n % 2 else (known[n // 2 - 1] + known[n // 2]) / 2
    return [med if v is None else v for v in vals]


def daily_means(station, truth_rows, vals):
    d = defaultdict(list)
    for (day, hour, _), v in zip(truth_rows, vals):
        if v is not None:
            d[day].append(v)
    return {k: statistics.fmean(v) for k, v in d.items()}


if __name__ == "__main__":
    truth, masked = make_masked()
    total = sum(len(v) for v in masked.values())
    missing = sum(1 for v in masked.values() for x in v if x is None)
    print(f"12 stations x 31 days = {total:,} hourly readings; {missing:,} ({missing / total * 100:.1f}%) removed (5% single readings + outages of 5-8 hours)")
    print(f"\n{'strategy':<34} {'readings kept':>13} {'station-days':>12} {'daily-mean error':>17} {'bias':>8} {'error of filled values':>23}")
    out = {}
    for name, fn in (("drop missing", strategy_drop), ("forward fill (at most 3 hours)", strategy_ffill),
                     ("fill with the station median", strategy_median)):
        errs, kept, days, fill_err = [], 0, 0, []
        for st in gen_data.STATIONS:
            vals = fn(masked[st])
            kept += sum(v is not None for v in vals)
            fill_err += [abs(v - t[2]) for m, v, t in zip(masked[st], vals, truth[st]) if m is None and v is not None]
            est = daily_means(st, truth[st], vals)
            tru = daily_means(st, truth[st], [r[2] for r in truth[st]])
            for day, tv in tru.items():
                if day in est:
                    errs.append(est[day] - tv)
                    days += 1
        mae, bias = statistics.fmean(abs(e) for e in errs), statistics.fmean(errs)
        fe = statistics.fmean(fill_err) if fill_err else float("nan")
        out[name] = {"kept": kept, "days": days, "mae": mae, "bias": bias, "fill_err": fe, "filled": len(fill_err)}
        print(f"{name:<34} {kept:>13,} {days:>12,} {mae:>16.3f}  {bias:>+8.3f} {('%.1f (%d values)' % (fe, len(fill_err))) if fill_err else '-':>23}")
    R["strategies"] = out
    print("(error = daily mean after the strategy minus the true daily mean, ug/m3; the true mean uses all readings)")

    print("\n=== time and memory of the three strategies on a series of n readings (5% missing) ===")
    print(f"{'n':>10} {'drop O(n)':>11} {'ffill O(n)':>11} {'median fill O(n log n)':>23} | peak memory MB: {'drop':>6} {'ffill':>6} {'median':>7}")
    timing = []
    for n in (100_000, 1_000_000):
        rnd = random.Random(1)
        vals = [None if rnd.random() < 0.05 else rnd.uniform(10, 150) for _ in range(n)]
        row = {"n": n}
        for name, fn in (("drop", lambda v: [x for x in v if x is not None]), ("ffill", strategy_ffill), ("median", strategy_median)):
            best = float("inf")
            for _ in range(3):
                t0 = time.perf_counter(); fn(vals); best = min(best, time.perf_counter() - t0)
            tracemalloc.start(); fn(vals); row["mem_" + name] = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
            row[name] = best
        timing.append(row)
        print(f"{n:>10,} {row['drop'] * 1000:>9.1f} ms {row['ffill'] * 1000:>9.1f} ms {row['median'] * 1000:>21.1f} ms | {'':>16}{row['mem_drop'] / 1e6:>6.1f} {row['mem_ffill'] / 1e6:>6.1f} {row['mem_median'] / 1e6:>7.1f}")
    R["timing"] = timing
    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(R, f, indent=1)
