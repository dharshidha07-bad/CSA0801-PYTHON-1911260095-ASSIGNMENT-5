"""Task A5.2 - a rule-based chatbot that answers air-quality questions from the SQLite database."""
import os
import re
import sqlite3

HERE = os.path.dirname(os.path.abspath(__file__))
POLLUTANTS = {"pm2.5": "pm25", "pm25": "pm25", "pm 2.5": "pm25", "pm10": "pm10", "pm 10": "pm10", "no2": "no2", "nitrogen": "no2",
              "temperature": "temp_c", "temp": "temp_c"}
NAMES = {"pm25": "PM2.5", "pm10": "PM10", "no2": "NO2", "temp_c": "temperature"}
UNITS = {"pm25": "ug/m3", "pm10": "ug/m3", "no2": "ug/m3", "temp_c": "C"}


def band(pm25):
    for limit, text in ((30, "good"), (60, "satisfactory"), (90, "moderate"), (120, "poor"), (250, "very poor")):
        if pm25 <= limit:
            return text
    return "severe"


def answer(question, con):
    q = question.lower()
    if re.search(r"\b(hi|hello|hey)\b", q):
        return "Hello! Ask me for example: 'What is the PM2.5 in Adyar today?' or 'Which station is the most polluted?'"
    col = next((c for k, c in POLLUTANTS.items() if k in q), "pm25")
    day = con.execute("SELECT MAX(day) FROM readings").fetchone()[0]
    if "polluted" in q or "worst station" in q or "highest" in q:
        row = con.execute(f"SELECT s.name, AVG(r.{col}) m FROM readings r JOIN stations s USING (station_id) WHERE r.day = ? "
                          f"GROUP BY s.name ORDER BY m DESC LIMIT 1", (day,)).fetchone()
        return f"On {day} the highest average {NAMES[col]} was at {row[0]}: {row[1]:.1f} {UNITS[col]}."
    names = [r[0] for r in con.execute("SELECT name FROM stations")]
    found = [n for n in names if n.lower() in q]
    if not found:
        return "I could not find a station name in your question. Stations: " + ", ".join(names) + "."
    st = found[0]
    if "hour" in q and ("worst" in q or "highest" in q):
        row = con.execute(f"SELECT r.hour, AVG(r.{col}) m FROM readings r JOIN stations s USING (station_id) WHERE s.name = ? "
                          f"GROUP BY r.hour ORDER BY m DESC LIMIT 1", (st,)).fetchone()
        return f"At {st} the worst hour for {NAMES[col]} is {row[0]}:00 (average {row[1]:.1f} {UNITS[col]})."
    row = con.execute(f"SELECT AVG(r.{col}), MIN(r.{col}), MAX(r.{col}) FROM readings r JOIN stations s USING (station_id) "
                      f"WHERE s.name = ? AND r.day = ?", (st, day)).fetchone()
    if row[0] is None:
        return f"There are no {NAMES[col]} readings for {st} on {day}."
    text = f"{st} on {day}: average {NAMES[col]} {row[0]:.1f} {UNITS[col]} (min {row[1]:.1f}, max {row[2]:.1f})."
    if col == "pm25":
        text += f" That is '{band(row[0])}' air."
    return text


if __name__ == "__main__":
    con = sqlite3.connect(os.path.join(HERE, "..", "B1", "air.db"))
    print("(the newest day in the database plays the role of 'today')")
    for qn in ["Hello", "What is the PM2.5 in Adyar today?", "pm10 at Guindy", "Which station is the most polluted?",
               "What is the worst hour for PM2.5 in Manali?", "What is the temperature at Royapuram today?",
               "How is the air in Chembur?", "Will it rain tomorrow?", "Is Adyar's air good for my asthma?"]:
        print(f"\nUser : {qn}\nBot  : {answer(qn, con)}")
