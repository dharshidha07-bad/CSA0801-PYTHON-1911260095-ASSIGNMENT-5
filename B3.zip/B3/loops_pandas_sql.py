"""Task B3 - daily mean PM2.5 per station: plain loops, pandas groupby, SQL GROUP BY."""
import csv
import cProfile
import io
import json
import os
import pstats
import sqlite3
import statistics
import sys
import time
import tracemalloc

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
import bigdata
import pandas as pd

R = {}


def by_loops(path):
    """csv module + dictionary of lists + statistics.mean."""
    groups = {}
    with open(path, encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        next(reader)
        for station, day, hour, pm25, *rest in reader:
            if pm25 != "":
                groups.setdefault((station, day), []).append(float(pm25))
    return {k: statistics.mean(v) for k, v in groups.items()}


def by_running_sum(path):
    """Alternative concept: one pass, running sum and count per (station, day); no readings kept."""
    acc = {}
    with open(path, encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        next(reader)
        for station, day, hour, pm25, *rest in reader:
            if pm25 != "":
                a = acc.setdefault((station, day), [0.0, 0])
                a[0] += float(pm25)
                a[1] += 1
    return {k: s / n for k, (s, n) in acc.items()}


def by_pandas(path):
    df = pd.read_csv(path, usecols=["station", "date", "pm25"])
    return df.groupby(["station", "date"])["pm25"].mean().to_dict()


def load_sqlite(path, con):
    con.execute("CREATE TABLE aq (station TEXT, day TEXT, hour INTEGER, pm25 REAL)")
    with open(path, encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        next(reader)
        con.executemany("INSERT INTO aq VALUES (?, ?, ?, ?)",
                        ((r[0], r[1], int(r[2]), float(r[3]) if r[3] != "" else None) for r in reader))
    con.commit()


def by_sql(con):
    return {(s, d): m for s, d, m in con.execute("SELECT station, day, AVG(pm25) FROM aq GROUP BY station, day")}


def same(a, b, places=6):
    return a.keys() == b.keys() and all(abs(a[k] - b[k]) < 10 ** -places for k in a)


def best(fn, reps):
    t = float("inf")
    for _ in range(reps):
        t0 = time.perf_counter()
        fn()
        t = min(t, time.perf_counter() - t0)
    return t


if __name__ == "__main__":
    print("=== B3.1 correctness on small data (3 stations x 5 days, 360 readings) ===")
    small = bigdata.ensure_csv(3, 5)
    con = sqlite3.connect(":memory:")
    load_sqlite(small, con)
    a, b, c, d = by_loops(small), by_pandas(small), by_sql(con), by_running_sum(small)
    print("groups (station, day):", len(a), "| first three:", [(k, round(v, 3)) for k, v in list(a.items())[:3]])
    print("loops == pandas:", same(a, b), "| loops == SQL:", same(a, c), "| pandas == SQL:", same(b, c), "| running sum == loops:", same(a, d))
    assert same(a, b) and same(a, c) and same(a, d)
    con.close()

    print("\n=== B3.2 time for 1, 12 and 120 stations over a year (best of 3; 1 run for the largest) ===")
    print(f"{'stations':>8} {'rows':>10} {'loops':>9} {'running':>9} {'pandas':>9} {'SQL load':>9} {'SQL query':>10} {'SQL total':>10}")
    rows_out = []
    for st in (1, 12, 120):
        path = bigdata.ensure_csv(st, 365)
        n = bigdata.row_count(path)
        reps = 3 if n < 500_000 else 1
        t_loops = best(lambda: by_loops(path), reps)
        t_run = best(lambda: by_running_sum(path), reps)
        t_pd = best(lambda: by_pandas(path), reps)
        con = sqlite3.connect(":memory:")
        t0 = time.perf_counter(); load_sqlite(path, con); t_load = time.perf_counter() - t0
        t_q = best(lambda: by_sql(con), reps)
        ref = by_loops(path)
        assert same(ref, by_pandas(path)) and same(ref, by_sql(con)) and same(ref, by_running_sum(path))
        con.close()
        rows_out.append({"stations": st, "rows": n, "loops": t_loops, "running": t_run, "pandas": t_pd, "sql_load": t_load, "sql_query": t_q})
        print(f"{st:>8} {n:>10,} {t_loops:>8.3f}s {t_run:>8.3f}s {t_pd:>8.3f}s {t_load:>8.3f}s {t_q:>9.3f}s {t_load + t_q:>9.3f}s", flush=True)
    print("All four methods give identical daily means at every size (checked to 6 decimals).")
    R["timing"] = rows_out

    print("\n=== B3.3 cProfile of the plain-Python version (12 stations, 105,120 rows) ===")
    path12 = bigdata.ensure_csv(12, 365)
    pr = cProfile.Profile()
    pr.enable()
    by_loops(path12)
    pr.disable()
    buf = io.StringIO()
    pstats.Stats(pr, stream=buf).strip_dirs().sort_stats("tottime").print_stats(8)
    text = buf.getvalue()
    start = text.index("ncalls")
    print(text[start - 200 if start > 200 else 0:].strip())
    stats = pstats.Stats(pr)
    top = sorted(stats.stats.items(), key=lambda kv: kv[1][2], reverse=True)[:3]
    R["profile_top"] = [{"func": f"{k[2]} ({os.path.basename(k[0])}:{k[1]})", "tottime": v[2], "ncalls": v[0]} for k, v in top]
    total_t = stats.total_tt
    R["profile_total"] = total_t
    mean_cum = next(v[3] for k, v in stats.stats.items() if k[2] == "mean" and "statistics" in k[0])
    loop_tot = next(v[2] for k, v in stats.stats.items() if k[2] == "by_loops")
    print(f"\nBy own time the largest entry is by_loops itself ({loop_tot:.3f} s: the csv reading/grouping loop); "
          f"statistics.mean, called {4380:,} times, costs {mean_cum:.3f} s cumulative = {mean_cum / total_t * 100:.0f}% of the {total_t:.3f} s profiled")
    R["profile_mean_cum"] = mean_cum
    R["profile_loop_tot"] = loop_tot

    print("\n=== Alternative concept: running sum in one pass versus store-all-then-statistics.mean (12 stations) ===")
    for label, fn in (("store all readings, then statistics.mean", by_loops), ("running sum and count", by_running_sum)):
        tracemalloc.start()
        res = fn(path12)
        peak = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        print(f"  {label:<42} groups={len(res):,} peak memory={peak / 1e6:6.1f} MB  time={best(lambda: fn(path12), 3):.3f}s")
        R.setdefault("alt_mem", {})[label] = peak
    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(R, f, indent=1)
