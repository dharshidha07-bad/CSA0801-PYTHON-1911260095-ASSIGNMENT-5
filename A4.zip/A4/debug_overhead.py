"""Task A4 alternative: print statements versus logging, and the cost of assert. Also shows pdb on the buggy script."""
import io
import json
import logging
import os
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
R = {}
N = 20_000
tmp = tempfile.mkdtemp()


def work(i):
    return (i * 7 % 101) / 3.0


def timed(fn):
    best = float("inf")
    for _ in range(3):
        t0 = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t0)
    return best


def base():
    for i in range(N):
        work(i)


f_print = open(os.path.join(tmp, "print.txt"), "w")


def with_print():
    for i in range(N):
        v = work(i)
        print(f"i={i} value={v}", file=f_print)


DEBUG = False


def print_guarded():
    for i in range(N):
        v = work(i)
        if DEBUG:
            print(f"i={i} value={v}", file=f_print)


lg_on = logging.getLogger("on"); lg_on.setLevel(logging.DEBUG); lg_on.addHandler(logging.FileHandler(os.path.join(tmp, "log.txt"))); lg_on.propagate = False
lg_off = logging.getLogger("off"); lg_off.setLevel(logging.WARNING); lg_off.addHandler(logging.FileHandler(os.path.join(tmp, "log2.txt"))); lg_off.propagate = False


def log_enabled():
    for i in range(N):
        v = work(i)
        lg_on.debug("i=%d value=%s", i, v)


def log_disabled():
    for i in range(N):
        v = work(i)
        lg_off.debug("i=%d value=%s", i, v)


def log_disabled_fstring():
    for i in range(N):
        v = work(i)
        lg_off.debug(f"i={i} value={v}")           # the f-string is built even though nothing is logged


def with_assert():
    for i in range(N):
        v = work(i)
        assert 0 <= v <= 40, "value out of range"


print(f"{N:,} loop iterations, each doing a little work; best of 3 (seconds)")
base_t = timed(base)
rows = [("no debugging output (baseline)", base_t)]
for label, fn in (("print() to a file on every iteration", with_print), ("print() inside 'if DEBUG:' with DEBUG = False", print_guarded),
                  ("logging.debug, level DEBUG, file handler", log_enabled), ("logging.debug, level WARNING (switched off)", log_disabled),
                  ("logging.debug(f-string), level WARNING", log_disabled_fstring), ("assert statement (assertions on)", with_assert)):
    rows.append((label, timed(fn)))
for label, t in rows:
    print(f"  {label:<48} {t:.4f} s   extra per call: {(t - base_t) / N * 1e6:6.2f} microseconds")
R["rows"] = rows

code = ("import time\nN=20000\n\ndef work(i):\n    return (i*7%101)/3.0\n\nbest=9\nfor _ in range(3):\n    t0=time.perf_counter()\n"
        "    for i in range(N):\n        v=work(i)\n        assert 0 <= v <= 40, 'x'\n    best=min(best,time.perf_counter()-t0)\nprint(round(best,4))\n")
t_on = float(subprocess.run([sys.executable, "-c", code], capture_output=True, text=True).stdout)
t_off = float(subprocess.run([sys.executable, "-O", "-c", code], capture_output=True, text=True).stdout)
print(f"  assert in a separate process: normal {t_on:.4f} s, python -O (assertions removed) {t_off:.4f} s")
R["assert"] = [t_on, t_off]

print("\n=== switching off ===")
print("  print      : delete the lines, or wrap them in 'if DEBUG:' (the test still costs a little), or redirect output; nothing is configurable from outside")
print("  logging    : logging.getLogger().setLevel(logging.WARNING) or an environment/config file; calls stay in the code and cost almost nothing")
print("  assert     : run with  python -O  (all asserts removed), no code change")
print("  debugger   : nothing to switch off; breakpoints exist only while the debugger is attached")

print("\n=== assert and logging on the buggy script (buggy_clean.py) ===")
r = subprocess.run([sys.executable, os.path.join(HERE, "buggy_clean.py")], capture_output=True, text=True)
print(r.stdout.strip())
print("\n".join(l for l in r.stderr.splitlines() if l.startswith("DEBUG") or l.startswith("AssertionError")))

print("\n=== pdb session on the same script (commands sent: b 15, c, c, p temp, n, n, p temp, q) ===")
cmds = "b 15\nc\nc\np temp\nn\nn\np temp\nq\n"
r = subprocess.run([sys.executable, "-m", "pdb", os.path.join(HERE, "buggy_clean.py")], input=cmds, capture_output=True, text=True, cwd=HERE)
for ln in r.stdout.splitlines():
    print("  " + ln.replace(HERE, "."))
with open(os.path.join(HERE, "results.json"), "w") as f:
    json.dump(R, f, indent=1)
