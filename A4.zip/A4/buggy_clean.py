"""A small cleaning function with a deliberate bug (used to show assert, logging and pdb)."""
import logging

log = logging.getLogger("cleaning")


def to_celsius(temp_f):
    temp_c = (temp_f - 32) * 5 / 9
    return temp_c


def clean_temperature(station, raw, is_fahrenheit):
    temp = float(raw)
    log.debug("station=%s raw=%s fahrenheit=%s", station, raw, is_fahrenheit)
    if is_fahrenheit:
        temp = to_celsius(temp) * 9 / 5 + 32          # BUG: converts to Celsius and straight back to Fahrenheit
    assert -10 <= temp <= 60, f"temperature {temp:.1f} C outside -10..60 for {station}"
    return temp


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format="%(levelname)s %(name)s: %(message)s")
    print("Adyar (Celsius):", clean_temperature("Adyar", "27.5", False))
    print("Manali (Fahrenheit):", clean_temperature("Manali", "80.6", True))
